create FUNCTION P_GET_JD_NEW(
  AC_FJD_DM VARCHAR2, --鐖惰妭鐐逛唬鐮�
  AC_JD_MC  VARCHAR2, --鑺傜偣鍚嶇О
  AC_FLAG   VARCHAR2  --'0'琛ㄧず鏌ユ壘QX_GNMK_TREE;'1'琛ㄧず鏌ユ壘QX_GNMB_GNMK(鍙檺浜庤秴绾х敤鎴�
)
  RETURN VARCHAR2 IS
  LN_ROW   VARCHAR2(30); --鑺傜偣浠ｇ爜
  LN_COUNT NUMBER(10); -- 琛屾暟锛屼复鏃跺彉閲�
  BEGIN
    IF AC_FLAG = '0'
    THEN
      SELECT COUNT(*)
      INTO LN_ROW
      FROM QX_GNMK_TREE
      WHERE JD_DM = AC_FJD_DM AND (JDLX_DM = '01' or jdlx_dm = '0'); --add by liuming
      IF LN_ROW <> 1
      THEN
        RAISE_APPLICATION_ERROR(-20000, '鐖惰妭鐐逛唬鐮侊細' || AC_FJD_DM || ' 涓嶆槸鐩綍锛屾棤娉曞悜涓嬫墿灞�);
      END IF;

      SELECT COUNT(*)
      INTO LN_ROW
      FROM QX_GNMK_TREE
      WHERE FJD_DM = AC_FJD_DM AND JD_MC = AC_JD_MC;
      IF LN_ROW > 0
      THEN
        RAISE_APPLICATION_ERROR(-20000, '鑺傜偣鍚嶇О閲嶅锛� || AC_JD_MC);
      END IF;

      IF LENGTH(AC_FJD_DM) > 18
      THEN
        SELECT MAX(JD_DM) + 1
        INTO LN_ROW
        FROM QX_GNMK_TREE
        WHERE JD_DM >= '0' AND JD_DM <= '9';
        RETURN LN_ROW;
      ELSE
        --閫氳繃鐖惰妭鐐逛唬鐮佸悜涓嬫墿灞曚笁浣嶏紝鐢熸垚鏂拌妭鐐逛唬鐮�
        SELECT MAX(JD_ORDER)
        INTO LN_ROW
        FROM QX_GNMK_TREE
        WHERE FJD_DM = AC_FJD_DM;
        IF LN_ROW IS NULL
        THEN
          LN_ROW := 1;
        ELSIF LN_ROW >= 999
          THEN
            RAISE_APPLICATION_ERROR(-20000, '涓嬪睘鑺傜偣瓒呰繃999锛屾棤娉曟墿灞曪紒');
        ELSE
          LN_ROW := LN_ROW + 1;
        END IF;

        -- 閬垮厤涓庣幇鏈変唬鐮侀噸澶�
        SELECT COUNT(*)
        INTO LN_COUNT
        FROM QX_GNMK_TREE
        WHERE JD_DM = AC_FJD_DM || LPAD(LN_ROW, 3, '0');
        WHILE LN_COUNT > 0 LOOP
          LN_ROW := LN_ROW + 1;
          SELECT COUNT(*)
          INTO LN_COUNT
          FROM QX_GNMK_TREE
          WHERE JD_DM = AC_FJD_DM || LPAD(LN_ROW, 3, '0');
        END LOOP;

        RETURN AC_FJD_DM || LPAD(LN_ROW, 3, '0');
      END IF;

    ELSE
      SELECT COUNT(*)
      INTO LN_ROW
      FROM QX_GNMB_GNMK
      WHERE JD_DM = AC_FJD_DM AND GNMK_DM = 'FFFFFFFFFFF' AND GNMB_DM = '00000000001';
      IF LN_ROW <> 1
      THEN
        RAISE_APPLICATION_ERROR(-20000, '鐖惰妭鐐逛唬鐮侊細' || AC_FJD_DM || ' 涓嶆槸鐩綍锛屾棤娉曞悜涓嬫墿灞�);
      END IF;

      SELECT COUNT(*)
      INTO LN_ROW
      FROM QX_GNMB_GNMK
      WHERE FJD_DM = AC_FJD_DM AND JD_MC = AC_JD_MC AND GNMB_DM = '00000000001';
      IF LN_ROW > 0
      THEN
        RAISE_APPLICATION_ERROR(-20000, '鑺傜偣鍚嶇О閲嶅锛� || AC_JD_MC);
      END IF;

      IF LENGTH(AC_FJD_DM) > 18
      THEN
        SELECT MAX(JD_DM) + 1
        INTO LN_ROW
        FROM QX_GNMB_GNMK
        WHERE GNMB_DM = '00000000001' AND JD_DM >= '0' AND JD_DM <= '9';
        RETURN LN_ROW;
      ELSE
        --閫氳繃鐖惰妭鐐逛唬鐮佸悜涓嬫墿灞曚笁浣嶏紝鐢熸垚鏂拌妭鐐逛唬鐮�
        SELECT MAX(JD_ORDER)
        INTO LN_ROW
        FROM QX_GNMB_GNMK
        WHERE FJD_DM = AC_FJD_DM AND GNMB_DM = '00000000001';
        IF LN_ROW IS NULL
        THEN
          LN_ROW := 1;
        ELSIF LN_ROW >= 999
          THEN
            RAISE_APPLICATION_ERROR(-20000, '涓嬪睘鑺傜偣瓒呰繃999锛屾棤娉曟墿灞曪紒');
        ELSE
          LN_ROW := LN_ROW + 1;
        END IF;

        -- 閬垮厤涓庣幇鏈変唬鐮侀噸澶�
        SELECT COUNT(*)
        INTO LN_COUNT
        FROM QX_GNMB_GNMK
        WHERE JD_DM = AC_FJD_DM || LPAD(LN_ROW, 3, '0');
        WHILE LN_COUNT > 0 LOOP
          LN_ROW := LN_ROW + 1;
          SELECT COUNT(*)
          INTO LN_COUNT
          FROM QX_GNMB_GNMK
          WHERE JD_DM = AC_FJD_DM || LPAD(LN_ROW, 3, '0');
        END LOOP;

        RETURN AC_FJD_DM || LPAD(LN_ROW, 3, '0');
      END IF;
    END IF;
  END;
/

