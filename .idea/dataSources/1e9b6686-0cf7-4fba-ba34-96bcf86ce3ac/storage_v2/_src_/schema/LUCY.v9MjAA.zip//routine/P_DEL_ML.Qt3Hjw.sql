create PROCEDURE P_DEL_ML(
  AC_FULL VARCHAR2, --鍏ㄨ矾寰勫悕绉�鍚勭骇闂寸敤~闅斿紑 濡傦細寰佹敹鐩戞帶~鐢虫姤寰佹敹~澧炲€肩◣鐢虫姤
  AC_HZMC VARCHAR2 --鐩綍鍚嶇О
) IS
  LC_JD_DM VARCHAR2(21);
  LN_ROW   NUMBER(10);
  BEGIN
    --閫氳繃鐩綍鍚嶇О鏌ユ壘鑺傜偣浠ｇ爜
    LC_JD_DM := P_GET_JD_DM(AC_FULL || '~' || AC_HZMC, '0');
    SELECT COUNT(*)
    INTO LN_ROW
    FROM QX_GNMK_TREE
    WHERE FJD_DM = LC_JD_DM;
    IF LN_ROW > 0
    THEN
      RAISE_APPLICATION_ERROR(-20000, '鍔熻兘妯″潡鏍戝瓨鍦ㄤ笅灞炶妭鐐癸紝鏃犳硶鍒犻櫎锛�);
    END IF;
    DELETE QX_GNMK_TREE
    WHERE JD_DM = LC_JD_DM;

    --鍚屾瓒呯骇鐢ㄦ埛鏍�鍦扮◣)
    LC_JD_DM := P_GET_JD_DM(AC_FULL || '~' || AC_HZMC, '1');
    SELECT COUNT(*)
    INTO LN_ROW
    FROM QX_GNMK_TREE
    WHERE FJD_DM = LC_JD_DM;
    IF LN_ROW > 0
    THEN
      RAISE_APPLICATION_ERROR(-20000, '鍔熻兘妯″潡鏍戝瓨鍦ㄤ笅灞炶妭鐐癸紝鏃犳硶鍒犻櫎锛�);
    END IF;
    DELETE QX_GNMB_GNMK
    WHERE GNMB_DM = '00000000001' AND JD_DM = LC_JD_DM;
  END;
/

