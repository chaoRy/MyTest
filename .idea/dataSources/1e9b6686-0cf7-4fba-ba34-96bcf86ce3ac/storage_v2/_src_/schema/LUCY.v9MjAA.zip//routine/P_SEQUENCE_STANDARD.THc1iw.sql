create FUNCTION P_SEQUENCE_STANDARD(sequenceNo out varchar2, sequenceName in varchar2)

  -----------------------------------------------------------------------------
  -----------------------------------------------------------------------------
  --                              瀛樺偍杩囩▼璇存槑
  --杩�绋�鍚嶏細P_SEQUENCE_STANDARD
  --鍔熻兘鎻忚堪锛氭爣鍑嗗簭鍒楄绠楀嚱鏁�
  --杈撳叆鍙傛暟锛氬簭鍒楀悕绉�
  --杈撳嚭鍙傛暟锛氬簭鍒楀€�
  --杩�鍥�鍊硷細100鎴愬姛 鍏朵粬鍊�绯荤粺閿欒
  --璋冪敤鏉ヨ嚜锛氬簭鍒楀彂鐢熷櫒
  --缂栧啓鏃堕棿锛�007骞�7鏈�0鏃�
  --缂�鍐�浜猴細Liudq
  --淇敼搴忓彿锛�
  --淇�鏀�浜猴細
  -----------------------------------------------------------------------------
  -----------------------------------------------------------------------------
  return number is
  jdno      varchar2(4); -- 鑺傜偣鍙�
  ln_return number(10); -- 杩斿洖鍊�
  begin
    execute immediate 'select to_char(' || sequenceName || '.nextval) from dual' into sequenceNo;
    ln_return := P_GET_JDH(jdno);
    if ln_return = 100
    then
      sequenceno := lpad(sequenceno, 8, '0');
      sequenceNo := jdno || to_char(sysdate, 'yy') || '9' || sequenceno || '000';
    end if;

    return ln_return;
  end;
/

