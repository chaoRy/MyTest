create view V_DM_BM as
  SELECT
    "JG_DM",
    "JG_MC",
    "JG_JC",
    "JG_BZ",
    "SJ_JG_DM",
    "DWLSGX_DM",
    "JG_JG",
    "JGYB",
    "JGDZ",
    "JGDH",
    "CZDH",
    "DYDZ",
    "XZQH_DM",
    "JGFZR_DM",
    "JBDM",
    "JCDM",
    "XYBZ",
    "YXBZ"
  FROM DM_JG
  WHERE YXBZ = 'Y'
        AND XYBZ = 'Y'
        AND JG_BZ = 'B'
/

