create view V_RS_RYXX as
  select
    "RY_DM",
    "RY_XM",
    "DW_JG_DM",
    "BM_JG_DM",
    "ADDRESS",
    "ZJHM",
    "DHHM",
    "SJHM",
    "EMAIL"
  from RS_RYXX
/

