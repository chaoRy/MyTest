create trigger TR_INSERT_FLOWLOG
  after insert
  on ESB2_TRANS_REQ_LOG
  for each row
  BEGIN
    --灏嗘柊澧炴暟鎹彃鍏ュ埌鏃ュ織璁板綍琛�ESBFLOWLOG_log ,浠ヤ緵monitor浣跨敤銆�
    INSERT INTO ESBFLOWLOG_log (esbflowno, ESBSERVICEFLOWNO, ESBSTATUS, RESPCODE, TRADESTATUS, BUSINESSRESPCODE, SERVICEID, CHANNELID, LOCATIONID, LOGSTAMP, LOOP, flowstepid, REALCHANNEL, REALSYSTEM, SERVICETYPE)
    VALUES (:new.esbflowno, :new.ESBSERVICEFLOWNO, :new.RespStatus, :new.respcode, :new.BUSINESSRESPSTATUS,
                            :new.businessrespcode, :new.serviceid, :new.logicchannel, :new.locationid, :new.operstamp,
                            :new.loopid, :new.flowstepid, :new.REALCHANNEL, :new.REALSYSTEM, :new.SERVICETYPE);

  END;
/

