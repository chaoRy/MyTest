create function ISYSZ(rydm in varchar2)
  return varchar2
is
  rynum integer;
  begin
    select count(*)
    into rynum
    from qx_user u
    where u.czry_dm = rydm;
    if (rynum > 0)
    then
      return '1';
    else
      return '0';
    end if;
  end ISYSZ;
/

