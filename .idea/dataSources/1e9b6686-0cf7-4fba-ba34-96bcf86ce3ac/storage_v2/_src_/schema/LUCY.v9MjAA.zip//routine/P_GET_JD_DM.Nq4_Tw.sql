create FUNCTION P_GET_JD_DM(
  AC_FULL VARCHAR2, --鍏ㄨ矾寰勫悕绉�鍚勭骇闂寸敤~闅斿紑
  AC_FLAG VARCHAR2  --'0'琛ㄧず鏌ユ壘QX_GNMK_TREE;'1'琛ㄧず鏌ユ壘QX_GNMB_GNMK(鍙檺浜庤秴绾х敤鎴�
)
  RETURN VARCHAR2 IS
  LC_FULL   VARCHAR2(1000); --鍏ㄨ矾寰勫悕绉�
  LN_POS    NUMBER(10); --~浣嶇疆
  LC_JD_MC  VARCHAR2(1000); --鑺傜偣鍚嶇О
  LC_FJD_DM VARCHAR2(30); --鐖惰妭鐐逛唬鐮�
  BEGIN
    LC_FULL := AC_FULL;
    LC_FJD_DM := '0'; --浠庢牴鑺傜偣0寮€濮�
    LOOP
      LN_POS := INSTR(LC_FULL, '~');
      IF LN_POS = 0
      THEN
        LC_JD_MC := LC_FULL;
      ELSE --濡傛灉鏈墌锛屽氨鎷嗗垎鍚嶇О
        LC_JD_MC := SUBSTR(LC_FULL, 1, LN_POS - 1);
        LC_FULL := SUBSTR(LC_FULL, LN_POS + 1);
      END IF;
      BEGIN
        --dbms_output.put_line(lc_jd_mc||' '||lc_fjd_dm);
        IF AC_FLAG = '0'
        THEN
          SELECT JD_DM
          INTO LC_FJD_DM
          FROM QX_GNMK_TREE
          WHERE FJD_DM = LC_FJD_DM AND JD_MC = LC_JD_MC;
        ELSE
          SELECT JD_DM
          INTO LC_FJD_DM
          FROM QX_GNMB_GNMK
          WHERE FJD_DM = LC_FJD_DM AND JD_MC = LC_JD_MC AND GNMB_DM = '00000000001';
        END IF;
        EXCEPTION
        WHEN OTHERS
        THEN RAISE_APPLICATION_ERROR(-20000, '鏌ユ壘璺緞鍚嶇О閿欒锛� || LC_JD_MC || '锛� || SQLERRM);
      END;
      IF LN_POS = 0
      THEN
        RETURN LC_FJD_DM; --杩斿洖鑺傜偣浠ｇ爜
      END IF;
    END LOOP;
  END;
/

