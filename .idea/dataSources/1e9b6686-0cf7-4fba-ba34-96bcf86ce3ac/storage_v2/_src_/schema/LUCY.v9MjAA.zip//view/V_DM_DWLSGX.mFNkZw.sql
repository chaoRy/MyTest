create view V_DM_DWLSGX as
  SELECT
    "DWLSGX_DM",
    "DWLSGX_MC",
    "XYBZ",
    "YXBZ"
  FROM DM_DWLSGX
  WHERE YXBZ = 'Y' AND XYBZ = 'Y'
/

