create PROCEDURE P_ADD_GNMK(
  AC_FULL       VARCHAR2, --鍏ㄨ矾寰勫悕绉�
  AC_GNMK       CHAR, --妯″潡浠ｇ爜
  AC_HZMC       VARCHAR2, --姹夊瓧鍚嶇О
  AC_LJMC       VARCHAR2, --璺緞鍚嶇О
  AC_YWHJ       CHAR, --涓氬姟鐜妭浠ｇ爜
  AC_MKLX_DM    VARCHAR2 default '05', --妯″潡绫诲瀷浠ｇ爜
  AC_SYSTEMNAME VARCHAR2 default '绯荤粺绠＄悊' --涓氬姟绯荤粺鍚嶇О
) IS
  LC_FJD_DM VARCHAR2(30);
  LC_JD_DM  VARCHAR2(30);
  LN_ROW    NUMBER(10);
  BEGIN
    IF AC_GNMK = 'FFFFFFFFFFF'
    THEN --澧炲姞鐩綍
      RAISE_APPLICATION_ERROR(-20000, '澧炲姞鐩綍璇疯皟鐢≒_ADD_ML');
    END IF;

    --寮€濮嬫彃鍏ユ暟鎹�
    BEGIN
      insert into QX_GNMK (GNMK_DM, GNMK_HZMC, GNMK_LJMC, MKLX_DM, YWHJ_DM, SYSTEMNAME, CYBJ, CFDK)
      values (AC_GNMK, AC_HZMC, AC_LJMC, AC_MKLX_DM, AC_YWHJ, AC_SYSTEMNAME, 'N', 'N'); --甯哥敤鏍囪涓篘
      EXCEPTION
      WHEN OTHERS
      THEN RAISE_APPLICATION_ERROR(-20000, 'GNMK_DM=' || AC_GNMK || ' ? ' || SQLERRM);
    END;

    IF AC_FULL IS NOT NULL
    THEN --AC_FULL涓虹┖锛岃〃绀轰笉鍦ㄦ爲涓婃樉绀�
      --閫氳繃鐩綍鍚嶇О鏌ユ壘鐖惰妭鐐逛唬鐮�
      LC_FJD_DM := P_GET_JD_DM(AC_FULL, '0');
      --鑾峰彇鏂拌妭鐐逛唬鐮�
      LC_JD_DM := P_GET_JD_NEW(LC_FJD_DM, AC_HZMC, '0');
      --       LN_ROW:=SUBSTR(LC_JD_DM,LENGTH(LC_JD_DM)-2,3);
      SELECT MAX(JD_ORDER)
      INTO LN_ROW
      FROM QX_GNMK_TREE
      WHERE FJD_DM = LC_FJD_DM;
      IF LN_ROW IS NULL
      THEN
        LN_ROW := 1;
      ELSIF LN_ROW >= 999
        THEN
          RAISE_APPLICATION_ERROR(-20000, '涓嬪睘鑺傜偣瓒呰繃999锛屾棤娉曟墿灞曪紒');
      ELSE
        LN_ROW := LN_ROW + 1;
      END IF;
      insert into QX_GNMK_TREE (JD_DM, FJD_DM, JD_MC, GNMK_DM, JDLX_DM, JD_ORDER)
      VALUES (LC_JD_DM, LC_FJD_DM, AC_HZMC, AC_GNMK, '02', LN_ROW);

      --閫氳繃鐩綍鍚嶇О鏌ユ壘鐖惰妭鐐逛唬鐮�
      LC_FJD_DM := P_GET_JD_DM(AC_FULL, '1');
      --鑾峰彇鏂拌妭鐐逛唬鐮�
      LC_JD_DM := P_GET_JD_NEW(LC_FJD_DM, AC_HZMC, '1');
      SELECT MAX(JD_ORDER)
      INTO LN_ROW
      FROM QX_GNMB_GNMK
      WHERE FJD_DM = LC_FJD_DM AND GNMB_DM = '00000000001';
      IF LN_ROW IS NULL
      THEN
        LN_ROW := 1;
      ELSIF LN_ROW >= 999
        THEN
          RAISE_APPLICATION_ERROR(-20000, '涓嬪睘鑺傜偣瓒呰繃999锛屾棤娉曟墿灞曪紒');
      ELSE
        LN_ROW := LN_ROW + 1;
      END IF;
      --        LN_ROW:=SUBSTR(LC_JD_DM,LENGTH(LC_JD_DM)-2,3);
      INSERT INTO QX_GNMB_GNMK (GNMB_DM, JD_DM, FJD_DM, JD_MC, GNMK_DM, JD_ORDER)
      VALUES ('00000000001', LC_JD_DM, LC_FJD_DM, AC_HZMC, AC_GNMK, LN_ROW);
    END IF;
  END;
/

