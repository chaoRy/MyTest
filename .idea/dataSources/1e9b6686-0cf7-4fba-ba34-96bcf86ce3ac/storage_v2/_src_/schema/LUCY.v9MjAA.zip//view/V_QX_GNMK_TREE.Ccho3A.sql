create view V_QX_GNMK_TREE as
  select
    JD_DM,
    FJD_DM,
    JD_MC,
    JDLX_DM,
    JD_ORDER,
    QX_GNMK.GNMK_DM,
    GNMK_HZMC,
    GNMK_LJMC,
    MKLX_DM,
    YWHJ_DM,
    CYBJ,
    GZL_BZ,
    CFDK,
    DKWZ,
    SHOWLEFT,
    SHOWTOP,
    SHOWINTREE,
    SYSTEMNAME,
    YXBZ
  from QX_GNMK_TREE
    inner join QX_GNMK on QX_GNMK_TREE.GNMK_DM = QX_GNMK.GNMK_DM
/

