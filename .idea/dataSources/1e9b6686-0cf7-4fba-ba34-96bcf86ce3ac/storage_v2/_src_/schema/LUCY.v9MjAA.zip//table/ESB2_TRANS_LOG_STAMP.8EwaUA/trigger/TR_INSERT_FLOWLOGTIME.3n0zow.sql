create trigger TR_INSERT_FLOWLOGTIME
  after insert
  on ESB2_TRANS_LOG_STAMP
  for each row
  BEGIN
    --灏嗘柊澧炴暟鎹彃鍏ュ埌鏃ュ織璁板綍琛�ESBFLOWLOG_time ,浠ヤ緵monitor浣跨敤銆�
    INSERT INTO ESBFLOWLOG_time (esbflowno, TIME1, TIME2, TIME3, TIME4, operstamp)
    VALUES (:new.esbflowno, :new.TRANSSTAMP1, :new.TRANSSTAMP2, :new.TRANSSTAMP3, :new.TRANSSTAMP4, sysdate);
  END;
/

