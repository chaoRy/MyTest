create PROCEDURE P_ADD_ML(
  AC_FULL VARCHAR2, --鍏ㄨ矾寰勫悕绉�鍚勭骇闂寸敤~闅斿紑
  AC_HZMC VARCHAR2 --鐩綍鍚嶇О
) IS
  LC_FJD_DM VARCHAR2(21);
  LC_JD_DM  VARCHAR2(21);
  LN_ROW    NUMBER(10);
  BEGIN
    --閫氳繃鐩綍鍚嶇О鏌ユ壘鐖惰妭鐐逛唬鐮�
    LC_FJD_DM := P_GET_JD_DM(AC_FULL, '0');
    SELECT COUNT(*)
    INTO LN_ROW
    FROM QX_GNMK_TREE
    WHERE FJD_DM = LC_FJD_DM AND JD_MC = AC_HZMC;
    IF LN_ROW = 0
    THEN
      BEGIN
        --鑾峰彇鏂拌妭鐐逛唬鐮�
        LC_JD_DM := P_GET_JD_NEW(LC_FJD_DM, AC_HZMC, '0');
        --    LN_ROW:=SUBSTR(LC_JD_DM,LENGTH(LC_JD_DM)-2,3);
        SELECT MAX(JD_ORDER)
        INTO LN_ROW
        FROM QX_GNMK_TREE
        WHERE FJD_DM = LC_FJD_DM;
        IF LN_ROW IS NULL
        THEN
          LN_ROW := 1;
        ELSIF LN_ROW >= 999
          THEN
            RAISE_APPLICATION_ERROR(-20000, '涓嬪睘鑺傜偣瓒呰繃999锛屾棤娉曟墿灞曪紒');
        ELSE
          LN_ROW := LN_ROW + 1;
        END IF;
        insert into QX_GNMK_TREE (JD_DM, FJD_DM, JD_MC, GNMK_DM, JDLX_DM, JD_ORDER)
        VALUES (LC_JD_DM, LC_FJD_DM, AC_HZMC, 'FFFFFFFFFFF', '01', LN_ROW);
      END;
    END IF;

    --閫氳繃鐩綍鍚嶇О鏌ユ壘鐖惰妭鐐逛唬鐮�
    LC_FJD_DM := P_GET_JD_DM(AC_FULL, '1');
    SELECT COUNT(*)
    INTO LN_ROW
    FROM QX_GNMB_GNMK
    WHERE FJD_DM = LC_FJD_DM AND JD_MC = AC_HZMC AND GNMB_DM = '00000000001';
    IF LN_ROW = 0
    THEN
      BEGIN
        --鑾峰彇鏂拌妭鐐逛唬鐮�
        LC_JD_DM := P_GET_JD_NEW(LC_FJD_DM, AC_HZMC, '1');
        --    LN_ROW:=SUBSTR(LC_JD_DM,LENGTH(LC_JD_DM)-2,3);
        SELECT MAX(JD_ORDER)
        INTO LN_ROW
        FROM QX_GNMB_GNMK
        WHERE FJD_DM = LC_FJD_DM AND GNMB_DM = '00000000001';
        IF LN_ROW IS NULL
        THEN
          LN_ROW := 1;
        ELSIF LN_ROW >= 999
          THEN
            RAISE_APPLICATION_ERROR(-20000, '涓嬪睘鑺傜偣瓒呰繃999锛屾棤娉曟墿灞曪紒');
        ELSE
          LN_ROW := LN_ROW + 1;
        END IF;
        INSERT INTO QX_GNMB_GNMK (GNMB_DM, JD_DM, FJD_DM, JD_MC, GNMK_DM, JD_ORDER)
        VALUES ('00000000001', LC_JD_DM, LC_FJD_DM, AC_HZMC, 'FFFFFFFFFFF', LN_ROW);
      END;
    END IF;
  END;
/

