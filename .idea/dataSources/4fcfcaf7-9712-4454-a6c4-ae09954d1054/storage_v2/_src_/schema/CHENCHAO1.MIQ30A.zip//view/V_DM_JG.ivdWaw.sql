create view V_DM_JG as
  select
	"JG_DM",
	"JG_MC",
	"JG_JC",
	"JG_BZ",
	"SJ_JG_DM",
	"DWLSGX_DM",
	"JG_JG",
	"JGYB",
	"JGDZ",
	"JGDH",
	"CZDH",
	"DYDZ",
	"XZQH_DM",
	"JGFZR_DM",
	"JBDM",
	"JCDM",
	"XYBZ",
	"YXBZ"
	from DM_JG
	where YXBZ = 'Y'
	and XYBZ = 'Y'
	order by JG_DM
/

