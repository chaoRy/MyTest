create PROCEDURE           P_ADD_GNMK(
    AC_FULL    VARCHAR2,--全路径名称
    AC_GNMK    CHAR,--模块代码
    AC_HZMC    VARCHAR2,--汉字名称
    AC_LJMC    VARCHAR2,--路径名称
    AC_YWHJ    CHAR,--业务环节代码
    AC_MKLX_DM    VARCHAR2 default '05', --模块类型代码
    AC_SYSTEMNAME    VARCHAR2 default '系统管理' --业务系统名称
)IS
    LC_FJD_DM  VARCHAR2(30);
    LC_JD_DM   VARCHAR2(30);
    LN_ROW     NUMBER(10);
BEGIN
    IF AC_GNMK='FFFFFFFFFFF' THEN--增加目录
        RAISE_APPLICATION_ERROR(-20000,'增加目录请调用P_ADD_ML');
    END IF;

    --开始插入数据
    BEGIN
        insert into QX_GNMK (GNMK_DM, GNMK_HZMC, GNMK_LJMC, MKLX_DM, YWHJ_DM, SYSTEMNAME, CYBJ, CFDK)
        values (AC_GNMK, AC_HZMC, AC_LJMC, AC_MKLX_DM, AC_YWHJ, AC_SYSTEMNAME, 'N','N');--常用标记为N
    EXCEPTION
        WHEN OTHERS THEN RAISE_APPLICATION_ERROR(-20000,'GNMK_DM='||AC_GNMK||' ? '||SQLERRM);
    END;

    IF AC_FULL IS NOT NULL THEN--AC_FULL为空，表示不在树上显示
        --通过目录名称查找父节点代码
        LC_FJD_DM:=P_GET_JD_DM(AC_FULL,'0');
        --获取新节点代码
        LC_JD_DM:=P_GET_JD_NEW(LC_FJD_DM,AC_HZMC,'0');
 --       LN_ROW:=SUBSTR(LC_JD_DM,LENGTH(LC_JD_DM)-2,3);
        SELECT MAX(JD_ORDER) INTO LN_ROW FROM QX_GNMK_TREE WHERE FJD_DM=LC_FJD_DM;
        IF LN_ROW IS NULL THEN
            LN_ROW:=1;
        ELSIF LN_ROW>=999 THEN
            RAISE_APPLICATION_ERROR(-20000,'下属节点超过999，无法扩展！');
        ELSE
            LN_ROW:=LN_ROW+1;
        END IF;
        insert into QX_GNMK_TREE(JD_DM,FJD_DM,JD_MC,GNMK_DM,JDLX_DM,JD_ORDER)
        VALUES (LC_JD_DM,LC_FJD_DM,AC_HZMC, AC_GNMK,'02',LN_ROW);

        --通过目录名称查找父节点代码
        LC_FJD_DM:=P_GET_JD_DM(AC_FULL,'1');
        --获取新节点代码
        LC_JD_DM:=P_GET_JD_NEW(LC_FJD_DM,AC_HZMC,'1');
        SELECT MAX(JD_ORDER) INTO LN_ROW FROM QX_GNMB_GNMK WHERE FJD_DM=LC_FJD_DM AND GNMB_DM='00000000001';
        IF LN_ROW IS NULL THEN
            LN_ROW:=1;
        ELSIF LN_ROW>=999 THEN
            RAISE_APPLICATION_ERROR(-20000,'下属节点超过999，无法扩展！');
        ELSE
            LN_ROW:=LN_ROW+1;
        END IF;
--        LN_ROW:=SUBSTR(LC_JD_DM,LENGTH(LC_JD_DM)-2,3);
        INSERT INTO QX_GNMB_GNMK(GNMB_DM,JD_DM,FJD_DM,JD_MC,GNMK_DM,JD_ORDER)
        VALUES ('00000000001',LC_JD_DM,LC_FJD_DM,AC_HZMC,AC_GNMK,LN_ROW);
    END IF;
END;
/

