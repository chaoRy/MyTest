create trigger TR_INSERT_FLOWLOGTIME
  after insert
  on ESB2_TRANS_LOG_STAMP
  for each row
  BEGIN
   --将新增数据插入到日志记录表 ESBFLOWLOG_time ,以供monitor使用。
   INSERT INTO ESBFLOWLOG_time(esbflowno,TIME1,TIME2,TIME3,TIME4,operstamp)
       VALUES( :new.esbflowno,:new.TRANSSTAMP1,:new.TRANSSTAMP2,:new.TRANSSTAMP3,:new.TRANSSTAMP4,sysdate);
END;
/

