create FUNCTION           P_SEQUENCE_STANDARD(sequenceNo out varchar2, sequenceName in varchar2)

-----------------------------------------------------------------------------
-----------------------------------------------------------------------------
--                              存储过程说明
--过 程 名：P_SEQUENCE_STANDARD
--功能描述：标准序列计算函数
--输入参数：序列名称
--输出参数：序列值
--返 回 值：100成功 其他值 系统错误
--调用来自：序列发生器
--编写时间：2007年07月30日
--编 写 人：Liudq
--修改序号：
--修 改 人：
-----------------------------------------------------------------------------
-----------------------------------------------------------------------------
return  number is
    jdno    varchar2(4); -- 节点号
    ln_return  number(10); -- 返回值
begin
    execute immediate 'select to_char(' || sequenceName || '.nextval) from dual' into sequenceNo;
    ln_return := P_GET_JDH(jdno);
    if ln_return = 100 then
      sequenceno := lpad(sequenceno,8,'0');
      sequenceNo := jdno||to_char(sysdate,'yy')||'9'||sequenceno||'000';
  end if;

  return ln_return;
end;
/

