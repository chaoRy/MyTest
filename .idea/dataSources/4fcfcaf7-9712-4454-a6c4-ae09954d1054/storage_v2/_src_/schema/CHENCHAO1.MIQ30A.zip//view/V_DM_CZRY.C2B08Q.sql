create view V_DM_CZRY as
  select dm_czry.czry_dm,czry_mc,jg_dm,zjhm,address,dhhm,sjhm,email,isysz(dm_czry.czry_dm)as isysz,qx_user.userid as userid
	from dm_czry left join qx_user on dm_czry.czry_dm=qx_user.czry_dm
/

