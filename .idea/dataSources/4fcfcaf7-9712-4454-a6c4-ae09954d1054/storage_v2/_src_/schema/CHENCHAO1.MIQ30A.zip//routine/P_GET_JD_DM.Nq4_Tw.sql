create FUNCTION           P_GET_JD_DM(
    AC_FULL VARCHAR2, --全路径名称 各级间用~隔开
    AC_FLAG VARCHAR2  --'0'表示查找QX_GNMK_TREE;'1'表示查找QX_GNMB_GNMK(只限于超级用户)
)RETURN VARCHAR2 IS
    LC_FULL     VARCHAR2(1000);--全路径名称
    LN_POS      NUMBER(10);    --~位置
    LC_JD_MC    VARCHAR2(1000);--节点名称
    LC_FJD_DM   VARCHAR2(30);  --父节点代码
BEGIN
    LC_FULL :=AC_FULL;
    LC_FJD_DM:='0';--从根节点0开始
    LOOP
        LN_POS:=INSTR(LC_FULL,'~');
        IF LN_POS=0 THEN
            LC_JD_MC:=LC_FULL;
        ELSE --如果有~，就拆分名称
            LC_JD_MC:=SUBSTR(LC_FULL,1,LN_POS-1);
            LC_FULL:=SUBSTR(LC_FULL,LN_POS+1);
        END IF;
        BEGIN
            --dbms_output.put_line(lc_jd_mc||' '||lc_fjd_dm);
            IF AC_FLAG='0' THEN
              SELECT JD_DM INTO LC_FJD_DM FROM QX_GNMK_TREE WHERE FJD_DM=LC_FJD_DM AND JD_MC=LC_JD_MC;
            ELSE
              SELECT JD_DM INTO LC_FJD_DM FROM QX_GNMB_GNMK WHERE FJD_DM=LC_FJD_DM AND JD_MC=LC_JD_MC AND GNMB_DM='00000000001';
          END IF;
        EXCEPTION
            WHEN OTHERS THEN RAISE_APPLICATION_ERROR(-20000,'查找路径名称错误：'||LC_JD_MC||'？'||SQLERRM);
        END;
        IF LN_POS=0 THEN
            RETURN LC_FJD_DM;--返回节点代码
        END IF;
    END LOOP;
END;
/

