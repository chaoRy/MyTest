create trigger TR_INSERT_FLOWLOG
  after insert
  on ESB2_TRANS_REQ_LOG
  for each row
  BEGIN
   --将新增数据插入到日志记录表 ESBFLOWLOG_log ,以供monitor使用。
     INSERT INTO ESBFLOWLOG_log(esbflowno,ESBSERVICEFLOWNO,ESBSTATUS,RESPCODE,TRADESTATUS,BUSINESSRESPCODE,SERVICEID,CHANNELID,LOCATIONID,LOGSTAMP,LOOP,flowstepid,REALCHANNEL,REALSYSTEM,SERVICETYPE)
     VALUES(:new.esbflowno,:new.ESBSERVICEFLOWNO,:new.RespStatus,:new.respcode,:new.BUSINESSRESPSTATUS,:new.businessrespcode,:new.serviceid,:new.logicchannel,:new.locationid,:new.operstamp,:new.loopid,:new.flowstepid,:new.REALCHANNEL,:new.REALSYSTEM,:new.SERVICETYPE);

END;
/

