create view SFWF_ROLE as
  SELECT distinct(g.roleid) as roleid, g.rolename as name, g.remark as description, 1 as open
      FROM SG_FRM_ROLEINFO g
/

