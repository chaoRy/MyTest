create view SFWF_V_PROCESSALARM as
  select sfwf_resendinfo.processid, sfwf_resendinfo.lastsendtime, sfwf_resendinfo.sendednumber,
	SFWF_processdefinition.name as taskid, SFWF_processdefinition.processdefinitionname as taskname,
	SFWF_processdefinition.name as pdid , SFWF_processdefinition.processdefinitionname as pdname,
	SFWF_processdefinition.ASSIGNEE as timelimit ,
	SFWF_instance.initiator as assignee, SFWF_instance.starttime, SFWF_instance.endtime, SFWF_instance.id as instanceid,
	SFWF_processdefinition.carlanderid,
	sfwf_definitiongroup.groupid
from sfwf_resendinfo , SFWF_instance , SFWF_processdefinition, sfwf_definitiongroup
where sfwf_resendinfo.processid = SFWF_instance.id  and SFWF_instance.processdefinitionname= SFWF_processdefinition.name
	and SFWF_processdefinition.processdefinitionname = sfwf_definitiongroup.definitionname
/

