create view SFWF_V_NODEVIEW as
  select SFWF_NODE.id as id,SFWF_NODE.name as nodename,FIRSTPROPERTY,SECONDPROPERTY,ASSIGNEE,
		conditiondescription,extend,time,starttime,endtime,priority,SFWF_activitymeta.name ,
		SFWF_NODE.icon as ICON,SFWF_NODE.type as type,SFWF_NODE.groupID as groupID,SFWF_node.PROCESSDEFINITIONNAME,SFWF_EVENT.URL,
		SFWF_NODE.EXPR
		from SFWF_ACTIVITYMETA , SFWF_NODE LEFT JOIN SFWF_EVENT ON SFWF_NODE.ID = SFWF_EVENT.NODEID
		where SFWF_NODE.type= SFWF_ACTIVITYMETA.type
/

