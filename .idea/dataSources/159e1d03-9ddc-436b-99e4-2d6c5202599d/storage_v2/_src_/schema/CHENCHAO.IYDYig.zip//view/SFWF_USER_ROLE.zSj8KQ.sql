create view SFWF_USER_ROLE as
  SELECT USERID,ROLEID from urm_role_mapping
/

