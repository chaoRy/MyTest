create view SFWF_V_PREVNODEVIEW as
  select SFWF_transition.id_to as id_to , SFWF_node.name as nodename,FIRSTPROPERTY,SECONDPROPERTY,
		SFWF_node.ASSIGNEE,conditiondescription,extend,time,starttime,endtime,priority, SFWF_activitymeta.name ,
		SFWF_node.id as id, SFWF_node.icon as ICON,SFWF_node.type as type,SFWF_node.groupID as groupID, SFWF_node.PROCESSDEFINITIONNAME,
		SFWF_NODE.EXPR
from SFWF_activitymeta , SFWF_node ,SFWF_transition
where SFWF_transition.id_from = SFWF_node.id  and SFWF_node.type= SFWF_activitymeta.type
/

