create view SFWF_USER as
  SELECT distinct(g.userid) as userid, g.userid as name, '0' as orgid, g.username as tname, '888888' as password, '1' as pwtype, 1 as open, null as BEGINDATE, null as ENDDATE
      FROM SG_FRM_USERINFO g
/

