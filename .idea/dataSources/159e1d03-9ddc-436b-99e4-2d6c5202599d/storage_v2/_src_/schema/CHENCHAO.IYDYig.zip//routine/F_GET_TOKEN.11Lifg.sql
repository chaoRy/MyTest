create FUNCTION F_GET_TOKEN
return  number is
    avc_xh_char varchar2(16);
    avc_xh  number;
begin
    select to_char(SEQ_TOKEN.nextval) into avc_xh from dual;
    avc_xh_char := lpad(avc_xh,8,'0');
    avc_xh_char := to_char(sysdate,'yyyymmdd')||avc_xh_char;
    avc_xh := to_number(avc_xh_char);
    return avc_xh;
end;
/

