create view SFWF_V_DONETASKALARM as
  select sfwf_resendinfo.processid, sfwf_resendinfo.lastsendtime, sfwf_resendinfo.sendednumber,
	SFWF_node.id as taskid , SFWF_node.name as taskname,SFWF_node.icon as timelimit ,
	SFWF_donetokenhistory.ASSIGNEE as assignee, SFWF_donetokenhistory.starttime, SFWF_donetokenhistory.endtime,
	SFWF_donetokenhistory.instanceid,
	SFWF_processdefinition.name as pdid , SFWF_processdefinition.processdefinitionname as pdname,
	SFWF_processdefinition.carlanderid ,
	sfwf_definitiongroup.groupid
from sfwf_resendinfo , SFWF_node , SFWF_donetokenhistory,  SFWF_processdefinition, sfwf_definitiongroup
where sfwf_resendinfo.processid = SFWF_donetokenhistory.id  and SFWF_donetokenhistory.activityid= SFWF_node.id
	and SFWF_node.processdefinitionname=SFWF_processdefinition.name
	and SFWF_processdefinition.processdefinitionname = sfwf_definitiongroup.definitionname
/

