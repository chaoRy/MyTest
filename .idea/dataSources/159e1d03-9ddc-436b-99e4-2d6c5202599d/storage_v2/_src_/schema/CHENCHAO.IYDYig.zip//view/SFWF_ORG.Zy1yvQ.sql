create view SFWF_ORG as
  SELECT distinct(g.orgid) as orgid, g.orgname as name, g.upperorg as parentid, '01' as jcid, g.remark as description, '1' as open
      FROM sg_frm_orginfo g
/

